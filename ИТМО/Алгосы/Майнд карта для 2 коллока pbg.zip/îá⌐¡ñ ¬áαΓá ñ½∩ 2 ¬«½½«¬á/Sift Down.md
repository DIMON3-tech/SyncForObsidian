[[Зачем используется sift down]]
[[Код sift down]]
[[Словесное описание sift down]]
[[За сколько работает sift down]]